﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Configuration.Provider;
using System.Configuration.Internal;

namespace BluePrismCodeAnalyzer
{
    public partial class Analyzer : Form
    {
        public Analyzer()
        {
            InitializeComponent();


        }
        
        private void button1_Click(object sender, EventArgs e)
        {
if((txtpath.Text) != "")
{ 
            try
            {
                string[] defaultList = System.Configuration.ConfigurationManager.AppSettings["InitialValueList"].ToString().Split(','); 
                string stage_name;

                // Move this to Function "PrepErrorListStructure"
                DataTable dtelement = new DataTable();
                DataColumn dcoleleid = new DataColumn("Element Id", typeof(String));
                dtelement.Columns.Add(dcoleleid);
                DataColumn dcolelename = new DataColumn("Element Name", typeof(String));
                dtelement.Columns.Add(dcolelename);

                DataTable dtsubsheet = new DataTable();
                DataColumn dcstageid = new DataColumn("Stage Id", typeof(String));
                dtsubsheet.Columns.Add(dcstageid);
                DataColumn dcstagename = new DataColumn("Stage Name", typeof(String));
                dtsubsheet.Columns.Add(dcstagename);

                DataTable dterrors = new DataTable();
                DataColumn dc = new DataColumn("Page / Action", typeof(String));
                dterrors.Columns.Add(dc);
                dc = new DataColumn("Stage Name", typeof(String));
                dterrors.Columns.Add(dc);
                dc = new DataColumn("Issue Description", typeof(String));
                dterrors.Columns.Add(dc);
                dc = new DataColumn("Category", typeof(String));
                dterrors.Columns.Add(dc);
                dc = new DataColumn("Severity", typeof(String));
                dterrors.Columns.Add(dc);
                //dc = new DataColumn("Page / Action", typeof(String));
                //dterrors.Columns.Add(dc);

                string tempval, Errormsg; 
                int noofaction = 0;
                XmlDocument doc = new XmlDocument();
                doc.Load(txtpath.Text);


                //XmlNodeList elemList = doc.GetElementsByTagName("process");


                // ********************* For Application Modeller Name Check****************************
                XmlNodeList elemList = doc.GetElementsByTagName("element");

                ElementChecks elecheck = new ElementChecks();
                elecheck.ElementCheck(elemList, dterrors); 

                //for (int i = 0; i < elemList.Count; i++)
                //{
                //    string attrVal = "";
                //    if (elemList[i].Attributes["name"] != null)
                //    {
                //        attrVal = elemList[i].Attributes["name"].Value;

                //        string ele = "Element";

                //        for (int j = 1; j < 10; j++)
                //        {
                //            ele = ele + j;
                //            if (attrVal == ele)
                //            {
                //                string firstchild = elemList[i].FirstChild.InnerText;

                //                DataRow dr = dterrors.NewRow();
                //                dr[2] = "Naming Convension Not Followed For Element which you Spied";
                //                dr[1] = attrVal;
                //                dr[0] = "Application Modeller";
                //                dr[4] = "Warning";
                //                dr[3] = "Best Practice";
                //                dterrors.Rows.Add(dr);
                //                //  }
                //                //}
                //            }
                //            ele = "Element";
                //        }
                //        //dataGridView1.DataSource = dterrors;
                //    }
                //}

                // ********************* ENd For Application Modeller Name Check****************************


                //------------------------------Add Element in Datatable
                for (int i = 0; i < elemList.Count; i++)
                {
                    if (elemList[i].Attributes["name"] != null)
                    {
                        string strelementname = elemList[i].Attributes["name"].Value;
                        string strelementid = elemList[i].FirstChild.InnerText;
                    
                        DataRow drow = dtelement.NewRow();
                        drow[1] = strelementname;
                        drow[0] = strelementid;
                        dtelement.Rows.Add(drow);
                    }

                }
                
                //------------------------------Add Element in Datatable


                //***********************search type of application*******************************
                XmlNodeList elemList1 = doc.GetElementsByTagName("appdef");

                
                elecheck.Apptype(elemList1,dterrors);  

                //for (int i = 0; i < elemList1.Count; i++)
                //{
                //    // XmlNodeList ConditionsNodes = elemList1[i].SelectSingleNode("apptypeinfo").ChildNodes;

                //    string ConditionsNodes = elemList1[i].SelectSingleNode("apptypeinfo").InnerText;
                //    if (ConditionsNodes.StartsWith("HTMLAttach"))
                //    {
                //        XmlNodeList elemList2 = doc.GetElementsByTagName("attribute");
                //        for (int x = 0; x < elemList2.Count; x++)
                //        {
                //            if (elemList2[x].Attributes["inuse"] != null)
                //            {
                //                string attrVal = elemList2[x].Attributes["inuse"].Value;
                //                string attrname = elemList2[x].Attributes["name"].Value;



                //                if (attrVal == "True" && attrname == "pURL")
                //                {
                //                    string elename = elemList2[x].Attributes["inuse"].OwnerElement.ParentNode.ParentNode.Attributes["name"].Value;
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "In Attribute Selection You Select Parent Make Sure it should Same in Production";
                //                    dr[1] = "Parent URL " + elename;
                //                    dr[0] = "Application Modeller";
                //                    dr[4] = "Warning";
                //                    dr[3] = "Learnt Lesson";
                //                    dterrors.Rows.Add(dr);


                //                }
                //                string attdatatype = elemList2[x].FirstChild.Attributes["datatype"].Value;
                //                string attvalue = elemList2[x].FirstChild.Attributes["value"].Value;

                //                if (attdatatype == "text" && attvalue == "")
                //                {
                //                    string elename = elemList2[x].Attributes["inuse"].OwnerElement.ParentNode.ParentNode.Attributes["name"].Value;
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "In Attribute Selection You Select Attribute Which Don't have Any Value";
                //                    dr[1] = "Attributes " + elename;
                //                    dr[0] = "Application Modeller";
                //                    dr[4] = "Warning";
                //                    dr[3] = "Learnt Lesson";
                //                    dterrors.Rows.Add(dr);
                //                }
                //            }

                //        }

                //    }

              //  }

                
                //***************************End type of Application**************************

                
                
                // ********************* For Counting Subsheet Count****************************
                XmlNodeList elemcnt = doc.GetElementsByTagName("subsheet");

                elecheck.sheetcheck(elemcnt,txtsubsheet.Text, dterrors );

                //if (elemcnt.Count > Int32.Parse(txtsubsheet.Text))
                //{
                //    DataRow dr = dterrors.NewRow();
                //    dr[2] = "Process/Object Contains more Actions / Sub pages";
                //    dr[1] = "General";
                //    dr[0] = "General";
                //    dr[4] = "Warning";
                //    dr[3] = "General";
                //    dterrors.Rows.Add(dr);
                   
                //}

                //*****************Add subsheet into Datatable*****************
                //XmlNodeList elemname1 = doc.GetElementsByTagName("subsheet");
                for (int i = 0; i < elemcnt.Count; i++)
                {
                    if (elemcnt[i].Attributes["type"].Value == "Normal")
                    {
                        string attrsheet = elemcnt[i].Attributes["subsheetid"].Value;

                        string attrname = elemcnt[i].FirstChild.InnerText;

                        //string attrname = elemname1[i].Attributes["name"].Value;

                        DataRow dr1 = dtsubsheet.NewRow();
                        dr1[1] = attrsheet;
                        dr1[0] = attrname;
                        dtsubsheet.Rows.Add(dr1);
                    }

                }
                //*****************Add subsheet into Datatable*****************

                // ********************* End of Counting Subsheet Count**************************


                

                //*********************Check Element is used in Current Object*********************
                XmlNodeList xmlsheet = doc.GetElementsByTagName("process");
                              
                elecheck.ElementUse(xmlsheet, dtelement, dterrors); 

                //for (int i = 0; i < dtelement.Rows.Count; i++)
                //{
                //    string fullxml = xmlsheet[0].OuterXml;

                //    int occuranceCount = (fullxml.Length - fullxml.Replace(dtelement.Rows[i][0].ToString(), "").Length) / dtelement.Rows[i][0].ToString().Length;

                //    if (occuranceCount == 1 || occuranceCount < 1) 
                //    {
                //        DataRow dr = dterrors.NewRow();
                //        dr[2] = "Element is Not Used in Current Object for Any Stage Please Make sure before Delete Whether it is Not Refere to any Other Object";
                //        dr[1] = dtelement.Rows[i][1].ToString();
                //        dr[0] = dtelement.Rows[i][1].ToString();
                //        dr[4] = "Best Practice";
                //        dr[3] = "Design";
                //        dterrors.Rows.Add(dr);
                //    }
                //}
                //*********************End of Check Element is used in Current Object*********************

               



                // ********************* Start to read for Write, Read, Collection Names****************************
                XmlNodeList elemname = doc.GetElementsByTagName("stage");
                Naming_Rule rules = new Naming_Rule();
                rules.NamingRule(elemname, dtsubsheet, dterrors);

                Description_Check desc = new Description_Check();
                desc.DescriptionCheck(elemname, dtsubsheet, dterrors);

                Wait_And_Timeouts_Checks waitchecks = new Wait_And_Timeouts_Checks();
                waitchecks.Waitchecks(elemname, dtsubsheet, dterrors);

                OtherChecks ochecks = new OtherChecks();
                ochecks.OtherRules(elemname, dtsubsheet, dterrors);

                
                //    if (attrVal == "Start")
                //    {
                //        for (int x = 0; x < elemname.Count; x++)
                //        {
                //            if (elemname[x].Attributes["type"].Value.ToString() != "Start")
                //            {
                //                //int noofaction = 0;
                //                noofaction = noofaction + 1;
                //            }
                //        }
                //        //MessageBox.Show(noofaction.ToString());
                //        noofaction = 0;
                //    }

                //}
                 

               
                // Wait Start

                

                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;

                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "WaitStart")
                //    {
                //        string temp = "Wait";
                        
                //        //Check for wait condition exists
                //        if (attrname == temp)
                //        {

                //            XmlNodeList ConditionsNodes = elemname[i].SelectSingleNode("choices").ChildNodes;

                //            string firstchild = elemname[i].FirstChild.InnerText;

                //            if (ConditionsNodes.Count <= 0)
                //            {
                //                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //                {
                //                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                    {
                //                        stage_name = dtsubsheet.Rows[k][0].ToString();
                //                        DataRow dr = dterrors.NewRow();
                //                        dr[2] = "Using Wait Stage without any condition";
                //                        dr[1] = attrname;
                //                        dr[0] = stage_name;
                //                        dr[4] = "Best Practice";
                //                        dr[3] = "Design";
                //                        dterrors.Rows.Add(dr);
                //                    }
                //                }
                //            }
                //        }

                //        //checking if Timeout value is hard coded

                //        Decimal dTimeOutValue = 0;
                //        string TimeOutValue = elemname[i].SelectSingleNode("timeout").InnerText;

                //        if (TimeOutValue == string.Empty || Decimal.TryParse(TimeOutValue, out dTimeOutValue) == true)
                //        {
                //            string firstchild = elemname[i].FirstChild.InnerText;

                //            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //            {
                //                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                {
                //                    stage_name = dtsubsheet.Rows[k][0].ToString();
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "Timeout hardcoded or empty.";
                //                    dr[1] = attrname;
                //                    dr[0] = stage_name;
                //                    dr[4] = "Warning";
                //                    dr[3] = "Best Practice";
                //                    dterrors.Rows.Add(dr);
                //                }
                //            }
                //        }
                //    }

                //}

               
                ////ExceptionTypes
                //List<string> lstApprovedExceptionTypes = new List<string> { "System Exception", "Business Exception", "Validation Exception", "Login Exception" };
                //// Start of Exception naming convention and Type checking....

                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;

                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "Exception")
                //    {


                //        string temp = "Exception";
                //        for (int j = 1; j < 10; j++)
                //        {

                //            temp = temp + j;
                //            if (attrname == temp)
                //            {
                //                string firstchild = elemname[i].FirstChild.InnerText;

                //                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //                {
                //                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                    {
                //                        stage_name = dtsubsheet.Rows[k][0].ToString();
                //                        DataRow dr = dterrors.NewRow();
                //                        dr[2] = "Naming Convension Not Followed For Exception Stage";
                //                        dr[1] = attrname;
                //                        dr[0] = stage_name;
                //                        dr[4] = "Warning";
                //                        dr[3] = "Best Practice";
                //                        dterrors.Rows.Add(dr);

                //                    }
                //                }
                //            }
                //            temp = "Exception";
                //        }

                //        //check if exception type is correct

                //        string ExceptionType = elemname[i].SelectSingleNode("exception").Attributes["type"].Value;

                //        if (lstApprovedExceptionTypes.Contains(ExceptionType) == false)
                //        {
                //            string firstchild = elemname[i].FirstChild.InnerText;

                //            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //            {
                //                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                {
                //                    stage_name = dtsubsheet.Rows[k][0].ToString();
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "Not using standard Exception Types";
                //                    dr[1] = ExceptionType;
                //                    dr[0] = stage_name;
                //                    dr[4] = "Warning";
                //                    dr[3] = "Best Practice";
                //                    dterrors.Rows.Add(dr);

                //                }
                //            }
                //        }

                //    }

                //}
                //// end of Exception Should be of specified types only

                ////Checking for actions calling published action(s)
                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;
                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "SubSheet")
                //    {
                //        string ProcessIdreferred = elemname[i].SelectSingleNode("processid").InnerText;

                //        XmlNodeList actions = doc.GetElementsByTagName("subsheet");
                //        foreach (XmlNode act in actions)
                //        {
                //            if (act.Attributes["subsheetid"].Value == ProcessIdreferred && act.Attributes["published"].Value == "True")
                //            {

                //                string firstchild = elemname[i].FirstChild.InnerText;
                //                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //                {
                //                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                    {
                //                        stage_name = dtsubsheet.Rows[k][0].ToString();
                //                        DataRow dr = dterrors.NewRow();
                //                        dr[2] = "Best Practices Violation: Calling published action within the Object";
                //                        dr[1] = attrname;
                //                        dr[0] = stage_name;
                //                        dr[4] = "Warning";
                //                        dr[3] = "Best Practice";
                //                        dterrors.Rows.Add(dr);
                //                    }
                //                }
                //            }

                //        }

                //    }
                //}

                ////*************************** Point f by Swapnil**************************************
                ////List<string> InitialValueList = new List<string> { "@C:/", "@D:/"};
                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;
                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "Data")
                //    {
                //        // string ProcessIdreferred = "";
                //        if (elemname[i].SelectSingleNode("datatype").InnerText.ToString() == "password")
                //        { }
                //        else
                //        {
                //            if (elemname[i].SelectSingleNode("initialvalue").InnerText.ToString() != "")
                //            {

                //                string ProcessIdreferred = elemname[i].SelectSingleNode("initialvalue").InnerText;
                //                //if (ProcessIdreferred.Contains("C:/") == true || ProcessIdreferred.Contains("D:/") == true)
                //                if (defaultList.Any(ProcessIdreferred.Contains)) 
                //                {

                //                    string firstchild = elemname[i].FirstChild.InnerText;
                //                    for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //                    {
                //                        if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                        {
                //                            stage_name = dtsubsheet.Rows[k][0].ToString();
                //                            DataRow dr = dterrors.NewRow();
                //                            dr[2] = "Best Practices Violation: Declaring Path in Data Item";
                //                            dr[1] = attrname;
                //                            dr[0] = stage_name;
                //                            dr[4] = "Warning";
                //                            dr[3] = "Best Practice";
                //                            dterrors.Rows.Add(dr);
                //                        }
                //                    }
                //                }
                //            }
                //        }

                //    }
                //}
                ////********************************Point f End**************************************

                ////*************************** Point j by Swapnil**************************************

                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;
                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "Process")
                //    {

                //        DataRow dr = dterrors.NewRow();
                //        dr[2] = "Best Practices Violation: Process Calling Process";
                //        dr[1] = attrname;
                //        dr[0] = attrname;
                //        dr[4] = "Warning";
                //        dr[3] = "Best Practice";
                //        dterrors.Rows.Add(dr);

                //    }
                //}
                ////********************************Point j End**************************************

                //*******************************point h by Vivek***********************************

                ////Checking for Recover and Resume in the actions
                //for (int i = 0; i < elemname.Count; i++)
                //{
                //    string attrVal = elemname[i].Attributes["type"].Value;
                //    string attrname = elemname[i].Attributes["name"].Value;

                //    if (attrVal == "Resume")
                //    {
                //        bool FoundGoingToEnd = false;
                //        XmlNode nextNode = elemname[i];
                //        for (int l = 0; l < 5; l++) // go upto five stages to check if its going to End stage
                //        {
                //            nextNode = CheckNextNode(nextNode, doc);
                //            if (nextNode != null) //added by swapnil
                //            {
                //                if (nextNode.Attributes["type"].Value == "End")
                //                {
                //                    FoundGoingToEnd = true;
                //                    break;
                //                }
                //                else
                //                {
                //                    FoundGoingToEnd = false;
                //                }
                //            }
                //        }
                //        if (FoundGoingToEnd)
                //        {
                //            string firstchild = elemname[i].FirstChild.InnerText;
                //            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //            {
                //                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                {
                //                    stage_name = dtsubsheet.Rows[k][0].ToString();
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "Best Practices Violation: Resume going to End stage is not recommended.";
                //                    dr[1] = attrname;
                //                    dr[0] = stage_name;
                //                    dr[4] = "Warning";
                //                    dr[3] = "Best Practice";
                //                    dterrors.Rows.Add(dr);
                //                }
                //            }

                //        }
                //    }
                //    //******************************pre-post cindition check***************************
                //    if (attrVal == "Start")
                //    {
                //        //string s = elemname[i].SelectSingleNode("onsuccess").InnerText;
                //        bool precodFound = false;
                //        XmlNode nextNode = elemname[i];
                //        for (int l = 0; l < 5; l++) // go upto five stages to check if its has waitstart stage
                //        {
                //            nextNode = CheckNextNode(nextNode, doc);
                //            if (nextNode != null) //added by swapnil
                //            {
                //                if (nextNode.Attributes["type"].Value == "WaitStart")
                //                {
                //                    precodFound = true;
                //                    break;
                //        //            //MessageBox.Show("true");
                //                }
                //                else
                //                {
                //                    precodFound = false;
                //                }

                //            }
                //        }
                //        if (precodFound == false)
                //        {
                //            string firstchild = elemname[i].FirstChild.InnerText;
                //            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //            {
                //                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //                {
                //                    stage_name = dtsubsheet.Rows[k][0].ToString();
                //                    DataRow dr = dterrors.NewRow();
                //                    dr[2] = "Pre Condition is not Placed in Starting 5 Stages of Subsheet";
                //                    dr[1] = attrname;
                //                    dr[0] = stage_name;
                //                    dr[4] = "Warning";
                //                    dr[3] = "Best Practice";
                //                    dterrors.Rows.Add(dr);
                //                }
                //            }

                //        }
                //       // elemname[i].SelectSingleNode("onsuccess").Value 
                //    }

                //    //if (attrVal == "WaitStart")
                //    //{
                //    //    //string s = elemname[i].SelectSingleNode("onsuccess").InnerText;
                //    //    bool precodFound = false;
                //    //    XmlNode nextNode = elemname[i];
                //    //    for (int l = 0; l < 5; l++) // go upto five stages to check if its has waitstart stage
                //    //    {
                //    //        nextNode = CheckNextNodeforpost(nextNode, doc);
                //    //        if (nextNode != null) //added by swapnil
                //    //        {
                //    //            if (nextNode.Attributes["type"].Value == "End")
                //    //            {
                //    //                precodFound = true;
                //    //                break;
                //    //                //            //MessageBox.Show("true");
                //    //            }
                //    //            else
                //    //            {
                //    //                precodFound = false;
                //    //            }

                //    //        }
                //    //    }
                //    //    if (precodFound == false)
                //    //    {
                //    //        string firstchild = elemname[i].FirstChild.InnerText;
                //    //        for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                //    //        {
                //    //            if (firstchild == dtsubsheet.Rows[k][1].ToString())
                //    //            {
                //    //                stage_name = dtsubsheet.Rows[k][0].ToString();
                //    //                DataRow dr = dterrors.NewRow();
                //    //                dr[2] = "Post Condition is not Placed in Ending 5 Stages of Subsheet";
                //    //                dr[1] = attrname;
                //    //                dr[0] = stage_name;
                //    //                dr[4] = "Warning";
                //    //                dr[3] = "Best Practice";
                //    //                dterrors.Rows.Add(dr);
                //    //            }
                //    //        }

                //    //    }
                //    //    // elemname[i].SelectSingleNode("onsuccess").Value 
                //    //}

                //}

                //*******************************point h end****************************************

                dataGridView1.DataSource = dterrors;
                dataGridView1.Columns[0].Width = 150;
                dataGridView1.Columns[1].Width = 100;
                dataGridView1.Columns[2].Width = 350;
                dataGridView1.Columns[3].Width = 100;
                dataGridView1.Columns[4].Width = 100;

            }
            catch (Exception ex)
            {
                //throw ex;

                MessageBox.Show(ex.ToString());
            }
    }
else
{
    MessageBox.Show("Please Select File to Start Code Analyzer");
}
        }

        //****************************
        //XmlNode CheckNextNodeforpost(XmlNode elemname, XmlDocument doc)
        //{
        //    if (elemname != null)
        //    {
        //        XmlNode CheckNextNode = elemname.SelectSingleNode("ontrue");
        //        if (CheckNextNode != null)
        //        {
        //            string nextNodelink = elemname.SelectSingleNode("ontrue").InnerText;

        //            XmlNodeList stages = doc.GetElementsByTagName("stage");

        //            foreach (XmlNode stage in stages)
        //            {
        //                if (stage.Attributes["stageid"].Value == nextNodelink)
        //                {
        //                    return stage;
        //                }
        //            }
        //        }
        //    }
        //    return null;
        //}
        //****************************
        //private void ReadError(string name, XmlNodeList elemname, string attributename, string child, string attname, DataTable dtsubsheet, DataTable dterrors, string errormsg)
        //{
        //    try
        //    {
        //        //for (int j = 1; j < 10; j++)
        //        //{
        //        //    string tem = name;
        //        //    name = name + j;
        //        //    if (attname == name)
        //        //    {
        //        Regex regex = new Regex(@"(\d+)$",RegexOptions.Compiled | RegexOptions.CultureInvariant);
        //        if (attname.StartsWith(name) && (attname.Length==name.Length +2 || attname.Length==name.Length +1) )
        //        {
        //            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
        //            {
        //                if (child == dtsubsheet.Rows[k][1].ToString())
        //                {
        //                    string stage_name = dtsubsheet.Rows[k][0].ToString();
        //                    DataRow dr = dterrors.NewRow();
        //                    dr[2] = errormsg;
        //                    dr[1] = attname;
        //                    dr[4] = "Warning";
        //                    dr[3] = "Best Practice";
        //                    dr[0] = stage_name;
        //                    dterrors.Rows.Add(dr);
        //                }
        //            }
        //        }
        //        //  name = tem;
        //    }
        //    //}
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        
        
        //start of addition function for point h
        XmlNode CheckNextNode(XmlNode elemname, XmlDocument doc)
        {
            if (elemname != null)
            {
                XmlNode CheckNextNode = elemname.SelectSingleNode("onsuccess");
                if (CheckNextNode != null)
                {
                    string nextNodelink = elemname.SelectSingleNode("onsuccess").InnerText;

                    XmlNodeList stages = doc.GetElementsByTagName("stage");

                    foreach (XmlNode stage in stages)
                    {
                        if (stage.Attributes["stageid"].Value == nextNodelink)
                        {
                            return stage;
                        }
                    }
                }
            }
            return null;
        }
        //end of addition function for point h

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtpath.Text = openFileDialog1.FileName;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.DefaultExt = ".xml";
            openFileDialog1.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog1.FileName = "";
            openFileDialog1.ShowDialog();
        }

        private void btnexport_Click(object sender, EventArgs e)
        {
            ExportGridToExcel();
        }
        private void ExportGridToExcel()
        {

            // Creating a Excel object. 
            Microsoft.Office.Interop.Excel._Application excel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = excel.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;

            try
            {

                worksheet = workbook.ActiveSheet;

                worksheet.Name = "ExportedFromDatGrid";

                int cellRowIndex = 1;
                int cellColumnIndex = 1;

                //Loop through each row and read value from each column. 
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        // Excel index starts from 1,1. As first Row would have the Column headers, adding a condition check. 
                        if (cellRowIndex == 1)
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridView1.Columns[j].HeaderText;
                        }
                        else
                        {
                            worksheet.Cells[cellRowIndex, cellColumnIndex] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }
                        cellColumnIndex++;
                    }
                    cellColumnIndex = 1;
                    cellRowIndex++;
                }

                //Getting the location and file name of the excel to save from user. 
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                saveDialog.FilterIndex = 2;

                if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    MessageBox.Show("Export Successful");
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                excel.Quit();
                workbook = null;
                excel = null;
            } 

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Setting s = new Setting();
            s.Show();
        }
    }
}