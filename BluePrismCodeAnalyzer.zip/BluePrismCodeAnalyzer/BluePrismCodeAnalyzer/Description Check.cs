﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;

namespace BluePrismCodeAnalyzer
{
    class Description_Check
    {
        public void DescriptionCheck(XmlNodeList elemname, DataTable dtsubsheet, DataTable dterrors)
        {
            string stage_name;
            try
            {
                //****************************Search for Input/Output parameters desciption******************

                // XmlNodeList ipelement = doc.GetElementsByTagName("stage");

                for (int i = 0; i < elemname.Count; i++)
                {

                    if (elemname[i].Attributes["type"].Value == "Start")
                    {
                        string attrname = elemname[i].Attributes["name"].Value;
                        if (elemname[i].SelectSingleNode("inputs") != null)
                        {
                            int cnt = 0;
                            cnt = elemname[i].SelectSingleNode("inputs").SelectNodes("input").Count;

                            for (int k = 0; k < cnt; k++)
                            {

                                if (elemname[i].SelectSingleNode("inputs").FirstChild.Attributes["narrative"] == null)
                                {
                                    for (int l = 0; l < dtsubsheet.Rows.Count; l++)
                                    {
                                        if (elemname[i].FirstChild.InnerText == dtsubsheet.Rows[l][1].ToString())
                                        {
                                            stage_name = dtsubsheet.Rows[k][0].ToString();
                                            DataRow dr = dterrors.NewRow();
                                            dr[2] = "Input Parameters Defined Without any Description.";
                                            dr[1] = attrname;
                                            dr[0] = stage_name;
                                            dr[4] = "Warning";
                                            dr[3] = "Best Practice";
                                            dterrors.Rows.Add(dr);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //}

                    if (elemname[i].Attributes["type"].Value == "End")
                    {
                        string attrname = elemname[i].Attributes["name"].Value;
                        if (elemname[i].SelectSingleNode("outputs") != null)
                        {
                            int cnt = 0;
                            cnt = elemname[i].SelectSingleNode("outputs").SelectNodes("output").Count;

                            for (int k = 0; k < cnt; k++)
                            {

                                if (elemname[i].SelectSingleNode("outputs").FirstChild.Attributes["narrative"] == null)
                                {

                                    for (int l = 0; l < dtsubsheet.Rows.Count; l++)
                                    {
                                        if (elemname[i].FirstChild.InnerText == dtsubsheet.Rows[l][1].ToString())
                                        {
                                            stage_name = dtsubsheet.Rows[k][0].ToString();
                                            DataRow dr = dterrors.NewRow();
                                            dr[2] = "Output Parameters Defined Without any Description.";
                                            dr[1] = attrname;
                                            dr[0] = stage_name;
                                            dr[4] = "Warning";
                                            dr[3] = "Best Practice";
                                            dterrors.Rows.Add(dr);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                //****************************END Search for Input/Output parameters desciption******************

            }
            catch (Exception ex)
            {
                
                throw ex;
            }

        }
    }
}
