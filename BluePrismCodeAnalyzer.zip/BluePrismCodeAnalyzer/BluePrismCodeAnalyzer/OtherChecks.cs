﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;

namespace BluePrismCodeAnalyzer
{
    class OtherChecks
    {
        public void OtherRules(XmlNodeList elemname, DataTable dtsubsheet, DataTable dterrors)
        {
            string stage_name;
            XmlDocument doc = new XmlDocument();
            string[] defaultList = System.Configuration.ConfigurationManager.AppSettings["InitialValueList"].ToString().Split(','); 
            try
            {
                //ExceptionTypes
                List<string> lstApprovedExceptionTypes = new List<string> { "System Exception", "Business Exception", "Validation Exception", "Login Exception" };
                // Start of Exception naming convention and Type checking....

                for (int i = 0; i < elemname.Count; i++)
                {
                    string attrVal = elemname[i].Attributes["type"].Value;

                    string attrname = elemname[i].Attributes["name"].Value;

                    if (attrVal == "Exception")
                    {


                        string temp = "Exception";
                        for (int j = 1; j < 10; j++)
                        {

                            temp = temp + j;
                            if (attrname == temp)
                            {
                                string firstchild = elemname[i].FirstChild.InnerText;

                                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                                {
                                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                    {
                                        stage_name = dtsubsheet.Rows[k][0].ToString();
                                        DataRow dr = dterrors.NewRow();
                                        dr[2] = "Naming Convension Not Followed For Exception Stage";
                                        dr[1] = attrname;
                                        dr[0] = stage_name;
                                        dr[4] = "Warning";
                                        dr[3] = "Best Practice";
                                        dterrors.Rows.Add(dr);

                                    }
                                }
                            }
                            temp = "Exception";
                        }

                        //check if exception type is correct

                        string ExceptionType = elemname[i].SelectSingleNode("exception").Attributes["type"].Value;

                        if (lstApprovedExceptionTypes.Contains(ExceptionType) == false)
                        {
                            string firstchild = elemname[i].FirstChild.InnerText;

                            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                            {
                                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                {
                                    stage_name = dtsubsheet.Rows[k][0].ToString();
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "Not using standard Exception Types";
                                    dr[1] = ExceptionType;
                                    dr[0] = stage_name;
                                    dr[4] = "Warning";
                                    dr[3] = "Best Practice";
                                    dterrors.Rows.Add(dr);

                                }
                            }
                        }

                    }

               // }
                // end of Exception Should be of specified types only

                //Checking for actions calling published action(s)
                //for (int i = 0; i < elemname.Count; i++)
                //{
                  //  string attrVal = elemname[i].Attributes["type"].Value;
                    //string attrname = elemname[i].Attributes["name"].Value;

                    if (attrVal == "SubSheet")
                    {
                        string ProcessIdreferred = elemname[i].SelectSingleNode("processid").InnerText;

                        XmlNodeList actions = doc.GetElementsByTagName("subsheet");
                        foreach (XmlNode act in actions)
                        {
                            if (act.Attributes["subsheetid"].Value == ProcessIdreferred && act.Attributes["published"].Value == "True")
                            {

                                string firstchild = elemname[i].FirstChild.InnerText;
                                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                                {
                                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                    {
                                        stage_name = dtsubsheet.Rows[k][0].ToString();
                                        DataRow dr = dterrors.NewRow();
                                        dr[2] = "Best Practices Violation: Calling published action within the Object";
                                        dr[1] = attrname;
                                        dr[0] = stage_name;
                                        dr[4] = "Warning";
                                        dr[3] = "Best Practice";
                                        dterrors.Rows.Add(dr);
                                    }
                                }
                            }

                        }

                    }
                    ////*************************** Point f by Swapnil**************************************
                    ////List<string> InitialValueList = new List<string> { "@C:/", "@D:/"};
                    //for (int i = 0; i < elemname.Count; i++)
                    //{
                    //    string attrVal = elemname[i].Attributes["type"].Value;
                    //    string attrname = elemname[i].Attributes["name"].Value;
                    if (attrVal == "Data")
                    {
                        // string ProcessIdreferred = "";
                        if (elemname[i].SelectSingleNode("datatype").InnerText.ToString() == "password")
                        { }
                        else
                        {
                            if (elemname[i].SelectSingleNode("initialvalue").InnerText.ToString() != "")
                            {

                                string ProcessIdreferred = elemname[i].SelectSingleNode("initialvalue").InnerText;
                                //if (ProcessIdreferred.Contains("C:/") == true || ProcessIdreferred.Contains("D:/") == true)
                                if (defaultList.Any(ProcessIdreferred.Contains))
                                {

                                    string firstchild = elemname[i].FirstChild.InnerText;
                                    for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                                    {
                                        if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                        {
                                            stage_name = dtsubsheet.Rows[k][0].ToString();
                                            DataRow dr = dterrors.NewRow();
                                            dr[2] = "Best Practices Violation: Declaring Path in Data Item";
                                            dr[1] = attrname;
                                            dr[0] = stage_name;
                                            dr[4] = "Warning";
                                            dr[3] = "Best Practice";
                                            dterrors.Rows.Add(dr);
                                        }
                                    }
                                }
                            }
                        }

                    }
                    //********************************Point f End**************************************
                    //*************************** Point j by Swapnil**************************************

                    //for (int i = 0; i < elemname.Count; i++)
                    //{
                      //  string attrVal = elemname[i].Attributes["type"].Value;
                        //string attrname = elemname[i].Attributes["name"].Value;

                        if (attrVal == "Process")
                        {

                            DataRow dr = dterrors.NewRow();
                            dr[2] = "Best Practices Violation: Process Calling Process";
                            dr[1] = attrname;
                            dr[0] = attrname;
                            dr[4] = "Warning";
                            dr[3] = "Best Practice";
                            dterrors.Rows.Add(dr);

                        }
                   // }
                    //********************************Point j End**************************************

                }

            }
            catch (Exception)
            {
                
                throw;
            }

        }
    }
}
