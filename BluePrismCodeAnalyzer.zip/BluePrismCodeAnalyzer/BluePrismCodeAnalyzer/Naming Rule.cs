﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Data;

namespace BluePrismCodeAnalyzer
{
    class Naming_Rule
    {
        public void NamingRule(XmlNodeList elemname, DataTable dtsubsheet, DataTable dterrors)
        {
            string tempval, Errormsg; 
            try
            {
                for (int i = 0; i < elemname.Count; i++)
                {
                    string attrVal = elemname[i].Attributes["type"].Value;

                    string attrname = elemname[i].Attributes["name"].Value;

                    if (attrVal == "Read")
                    {
                        tempval = "Read";
                        Errormsg = "Naming Convension Not Followed For Read Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);

                        // name.ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }
                    if (attrVal == "Write")
                    {
                        tempval = "Writer";
                        Errormsg = "Naming Convension Not Followed For Write Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "Calculation")
                    {
                        tempval = "Calc";
                        Errormsg = "Naming Convension Not Followed For Calculation Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "Collection")
                    {
                        tempval = "Coll";
                        Errormsg = "Naming Convension Not Followed For Collection Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "WaitStart")
                    {
                        tempval = "Wait";
                        Errormsg = "Naming Convension Not Followed For Wait Start Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "WaitEnd")
                    {
                        tempval = "Time Out";
                        Errormsg = "Naming Convension Not Followed For Time Out Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "Decision")
                    {
                        tempval = "Decision";
                        Errormsg = "Naming Convension Not Followed For Decision Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    if (attrVal == "Navigate")
                    {
                        tempval = "Navigate";
                        Errormsg = "Naming Convension Not Followed For Navigate Stage";
                        string firstchild = elemname[i].FirstChild.InnerText;
                        ReadError(tempval, elemname, attrVal, firstchild, attrname, dtsubsheet, dterrors, Errormsg);
                    }

                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
                public void ReadError(string name, XmlNodeList elemname, string attributename, string child, string attname, DataTable dtsubsheet, DataTable dterrors, string errormsg)
        {
            try
            {
                //for (int j = 1; j < 10; j++)
                //{
                //    string tem = name;
                //    name = name + j;
                //    if (attname == name)
                //    {
                Regex regex = new Regex(@"(\d+)$", RegexOptions.Compiled | RegexOptions.CultureInvariant);
                if (attname.StartsWith(name) && (attname.Length == name.Length + 2 || attname.Length == name.Length + 1))
                {
                    for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                    {
                        if (child == dtsubsheet.Rows[k][1].ToString())
                        {
                            string stage_name = dtsubsheet.Rows[k][0].ToString();
                            DataRow dr = dterrors.NewRow();
                            dr[2] = errormsg;
                            dr[1] = attname;
                            dr[4] = "Warning";
                            dr[3] = "Best Practice";
                            dr[0] = stage_name;
                            dterrors.Rows.Add(dr);
                        }
                    }
                }
                //  name = tem;
            }
            //}
            
       
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
    }
}
        
    

