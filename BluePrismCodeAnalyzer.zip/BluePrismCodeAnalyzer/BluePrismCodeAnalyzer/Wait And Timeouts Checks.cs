﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;

namespace BluePrismCodeAnalyzer
{
    class Wait_And_Timeouts_Checks
    {
        public void Waitchecks(XmlNodeList elemname, DataTable dtsubsheet, DataTable dterrors)
        {
            string stage_name;
            XmlDocument doc = new XmlDocument();
            try
            {
                for (int i = 0; i < elemname.Count; i++)
                {
                    string attrVal = elemname[i].Attributes["type"].Value;

                    string attrname = elemname[i].Attributes["name"].Value;

                    if (attrVal == "WaitStart")
                    {
                        string temp = "Wait";
                        
                        //Check for wait condition exists
                        if (attrname == temp)
                        {

                            XmlNodeList ConditionsNodes = elemname[i].SelectSingleNode("choices").ChildNodes;

                            string firstchild = elemname[i].FirstChild.InnerText;

                            if (ConditionsNodes.Count <= 0)
                            {
                                for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                                {
                                    if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                    {
                                        stage_name = dtsubsheet.Rows[k][0].ToString();
                                        DataRow dr = dterrors.NewRow();
                                        dr[2] = "Using Wait Stage without any condition";
                                        dr[1] = attrname;
                                        dr[0] = stage_name;
                                        dr[4] = "Best Practice";
                                        dr[3] = "Design";
                                        dterrors.Rows.Add(dr);
                                    }
                                }
                            }
                        }

                        //checking if Timeout value is hard coded

                        Decimal dTimeOutValue = 0;
                        string TimeOutValue = elemname[i].SelectSingleNode("timeout").InnerText;

                        if (TimeOutValue == string.Empty || Decimal.TryParse(TimeOutValue, out dTimeOutValue) == true)
                        {
                            string firstchild = elemname[i].FirstChild.InnerText;

                            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                            {
                                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                {
                                    stage_name = dtsubsheet.Rows[k][0].ToString();
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "Timeout hardcoded or empty.";
                                    dr[1] = attrname;
                                    dr[0] = stage_name;
                                    dr[4] = "Warning";
                                    dr[3] = "Best Practice";
                                    dterrors.Rows.Add(dr);
                                }
                            }
                        }
                    }

                }

            

            //Checking for Recover and Resume in the actions
                for (int i = 0; i < elemname.Count; i++)
                {
                    string attrVal = elemname[i].Attributes["type"].Value;
                    string attrname = elemname[i].Attributes["name"].Value;

                    if (attrVal == "Resume")
                    {
                        bool FoundGoingToEnd = false;
                        XmlNode nextNode = elemname[i];
                        for (int l = 0; l < 5; l++) // go upto five stages to check if its going to End stage
                        {
                            nextNode = CheckNextNode(nextNode, doc);
                            if (nextNode != null) //added by swapnil
                            {
                                if (nextNode.Attributes["type"].Value == "End")
                                {
                                    FoundGoingToEnd = true;
                                    break;
                                }
                                else
                                {
                                    FoundGoingToEnd = false;
                                }
                            }
                        }
                        if (FoundGoingToEnd)
                        {
                            string firstchild = elemname[i].FirstChild.InnerText;
                            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                            {
                                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                {
                                    stage_name = dtsubsheet.Rows[k][0].ToString();
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "Best Practices Violation: Resume going to End stage is not recommended.";
                                    dr[1] = attrname;
                                    dr[0] = stage_name;
                                    dr[4] = "Warning";
                                    dr[3] = "Best Practice";
                                    dterrors.Rows.Add(dr);
                                }
                            }

                        }
                    }
                    //******************************pre-post cindition check***************************
                    if (attrVal == "Start")
                    {
                        //string s = elemname[i].SelectSingleNode("onsuccess").InnerText;
                        bool precodFound = false;
                        XmlNode nextNode = elemname[i];
                        for (int l = 0; l < 5; l++) // go upto five stages to check if its has waitstart stage
                        {
                            nextNode = CheckNextNode(nextNode, doc);
                            if (nextNode != null) //added by swapnil
                            {
                                if (nextNode.Attributes["type"].Value == "WaitStart")
                                {
                                    precodFound = true;
                                    break;
                                    //            //MessageBox.Show("true");
                                }
                                else
                                {
                                    precodFound = false;
                                }

                            }
                        }
                        if (precodFound == false)
                        {
                            string firstchild = elemname[i].FirstChild.InnerText;
                            for (int k = 0; k < dtsubsheet.Rows.Count; k++)
                            {
                                if (firstchild == dtsubsheet.Rows[k][1].ToString())
                                {
                                    stage_name = dtsubsheet.Rows[k][0].ToString();
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "Pre Condition is not Placed in Starting 5 Stages of Subsheet";
                                    dr[1] = attrname;
                                    dr[0] = stage_name;
                                    dr[4] = "Warning";
                                    dr[3] = "Best Practice";
                                    dterrors.Rows.Add(dr);
                                }
                            }

                        }
                        // elemname[i].SelectSingleNode("onsuccess").Value 
                    }
                } 
            }
 catch (Exception)
            {
                
                throw;
            }
        }
                //start of addition function for point h
            XmlNode CheckNextNode(XmlNode elemname, XmlDocument doc)
        {
            if (elemname != null)
            {
                XmlNode CheckNextNode = elemname.SelectSingleNode("onsuccess");
                if (CheckNextNode != null)
                {
                    string nextNodelink = elemname.SelectSingleNode("onsuccess").InnerText;

                    XmlNodeList stages = doc.GetElementsByTagName("stage");

                    foreach (XmlNode stage in stages)
                    {
                        if (stage.Attributes["stageid"].Value == nextNodelink)
                        {
                            return stage;
                        }
                    }
                }
            }
            return null;
        }

                }
            
}   

    

