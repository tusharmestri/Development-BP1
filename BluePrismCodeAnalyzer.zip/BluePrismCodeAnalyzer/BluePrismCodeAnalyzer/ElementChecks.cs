﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Data;

namespace BluePrismCodeAnalyzer
{
    class ElementChecks
    {
        public void ElementCheck(XmlNodeList elemList, DataTable dterrors)
        {
            try
            {
                // ********************* For Application Modeller Name Check****************************
                //XmlNodeList elemList = doc.GetElementsByTagName("element");
                for (int i = 0; i < elemList.Count; i++)
                {
                    string attrVal = "";
                    if (elemList[i].Attributes["name"] != null)
                    {
                        attrVal = elemList[i].Attributes["name"].Value;

                        string ele = "Element";

                        for (int j = 1; j < 10; j++)
                        {
                            ele = ele + j;
                            if (attrVal == ele)
                            {
                                string firstchild = elemList[i].FirstChild.InnerText;

                                DataRow dr = dterrors.NewRow();
                                dr[2] = "Naming Convension Not Followed For Element which you Spied";
                                dr[1] = attrVal;
                                dr[0] = "Application Modeller";
                                dr[4] = "Warning";
                                dr[3] = "Best Practice";
                                dterrors.Rows.Add(dr);
                                //  }
                                //}
                            }
                            ele = "Element";
                        }
                        //dataGridView1.DataSource = dterrors;
                    }
                }
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }
        //***********************search type of application*******************************
        public void Apptype(XmlNodeList elemList, DataTable dterrors)
        {
            XmlDocument doc = new XmlDocument();
            try
            {
                for (int i = 0; i < elemList.Count; i++)
                {
                    // XmlNodeList ConditionsNodes = elemList1[i].SelectSingleNode("apptypeinfo").ChildNodes;

                    string ConditionsNodes = elemList[i].SelectSingleNode("apptypeinfo").InnerText;
                    if (ConditionsNodes.StartsWith("HTMLAttach"))
                    {
                        XmlNodeList elemList2 = doc.GetElementsByTagName("attribute");
                        for (int x = 0; x < elemList2.Count; x++)
                        {
                            if (elemList2[x].Attributes["inuse"] != null)
                            {
                                string attrVal = elemList2[x].Attributes["inuse"].Value;
                                string attrname = elemList2[x].Attributes["name"].Value;



                                if (attrVal == "True" && attrname == "pURL")
                                {
                                    string elename = elemList2[x].Attributes["inuse"].OwnerElement.ParentNode.ParentNode.Attributes["name"].Value;
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "In Attribute Selection You Select Parent Make Sure it should Same in Production";
                                    dr[1] = "Parent URL " + elename;
                                    dr[0] = "Application Modeller";
                                    dr[4] = "Warning";
                                    dr[3] = "Learnt Lesson";
                                    dterrors.Rows.Add(dr);


                                }
                                string attdatatype = elemList2[x].FirstChild.Attributes["datatype"].Value;
                                string attvalue = elemList2[x].FirstChild.Attributes["value"].Value;

                                if (attdatatype == "text" && attvalue == "")
                                {
                                    string elename = elemList2[x].Attributes["inuse"].OwnerElement.ParentNode.ParentNode.Attributes["name"].Value;
                                    DataRow dr = dterrors.NewRow();
                                    dr[2] = "In Attribute Selection You Select Attribute Which Don't have Any Value";
                                    dr[1] = "Attributes " + elename;
                                    dr[0] = "Application Modeller";
                                    dr[4] = "Warning";
                                    dr[3] = "Learnt Lesson";
                                    dterrors.Rows.Add(dr);
                                }
                            }

                        }

                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        //***********************END of search type of application*******************************

        //*********************Check Element is used in Current Object*********************
        public void ElementUse(XmlNodeList xmlsheet, DataTable dtelement, DataTable dterrors)
        {
            try
            {
                for (int i = 0; i < dtelement.Rows.Count; i++)
                {
                    string fullxml = xmlsheet[0].OuterXml;

                    int occuranceCount = (fullxml.Length - fullxml.Replace(dtelement.Rows[i][0].ToString(), "").Length) / dtelement.Rows[i][0].ToString().Length;

                    if (occuranceCount == 1 || occuranceCount < 1) 
                    {
                        DataRow dr = dterrors.NewRow();
                        dr[2] = "Element is Not Used in Current Object for Any Stage Please Make sure before Delete Whether it is Not Refere to any Other Object";
                        dr[1] = dtelement.Rows[i][1].ToString();
                        dr[0] = dtelement.Rows[i][1].ToString();
                        dr[4] = "Best Practice";
                        dr[3] = "Design";
                        dterrors.Rows.Add(dr);
                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }
        //*********************End of Check Element is used in Current Object*********************

        // ********************* For Counting Subsheet Count****************************
        public void sheetcheck(XmlNodeList elemcnt, string subsheet, DataTable dterrors)
        {
            try
            {
                if (elemcnt.Count > Int32.Parse(subsheet))
                {
                    DataRow dr = dterrors.NewRow();
                    dr[2] = "Process/Object Contains more Actions / Sub pages";
                    dr[1] = "General";
                    dr[0] = "General";
                    dr[4] = "Warning";
                    dr[3] = "General";
                    dterrors.Rows.Add(dr);
                   
                }
            }
            catch (Exception)
            {
                
                throw;
            }
        }

    }
}
